from __future__ import unicode_literals
from django.shortcuts import render, HttpResponse, redirect
from django.utils.crypto import get_random_string
 
def index(request):
  context = {
  "randnum": get_random_string(length=14)
  }
  return render(request,'main/index.html', context)